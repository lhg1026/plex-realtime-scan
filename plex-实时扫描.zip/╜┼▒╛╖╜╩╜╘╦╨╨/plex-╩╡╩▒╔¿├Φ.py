import os
import time
import logging
import configparser
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
import requests
import threading
import traceback
import schedule

class CustomEventHandler(FileSystemEventHandler):
    def __init__(self, config):
        super().__init__()
        self.config = config
        self.pending_events = {}
        self.scan_delay = int(config.get('DEFAULT', 'scan_delay'))
        self.lock = threading.Lock()
        self.timers = {} 

    def on_modified(self, event):
        self.process(event)

    def on_created(self, event):
        self.process(event)

    def on_deleted(self, event):
        self.process(event)

    def on_moved(self, event):
        self.process(event)



    def process(self, event):
        if event.is_directory:
            return None

        event_dir_path = os.path.dirname(event.src_path)
        for section in self.config.sections():
            if section.startswith("LIBRARIES"):
                library_id = self.config.get(section, '库ID')
                source_dir = self.config.get(section, '源目录')
                mount_dir = self.config.get(section, '挂载目录')
                directories = [self.config.get(section, key).strip() for key in self.config.options(section) if key not in ['源目录', '挂载目录', '库ID']]
                for dir_path in directories:
                    abs_dir_path = os.path.abspath(os.path.join(source_dir, dir_path))
                    if event_dir_path.startswith(abs_dir_path):
                        src_path = event.src_path.replace(source_dir, mount_dir)
                        message = f'库ID: {library_id}  路径: {src_path}'
                        with self.lock:
                            self.pending_events.setdefault(event_dir_path, []).append(src_path)

                        self.start_scan_timer(event_dir_path, library_id) 
                        return 

    def start_scan_timer(self, directory_path, library_id):
        with self.lock:
            if directory_path not in self.pending_events:
                return

        timer = self.timers.get(directory_path)
        if timer is not None:
            timer.cancel()

        timer = threading.Timer(self.scan_delay, self.trigger_scan, args=(directory_path, library_id))  
        self.timers[directory_path] = timer
        timer.start()

    def trigger_scan(self, directory_path, library_id):  
        with self.lock:
            if directory_path in self.pending_events:
                try:
                    source_dir = None
                    for section in self.config.sections():
                        if section.startswith("LIBRARIES"):
                            if self.config.get(section, '库ID') == library_id:
                                source_dir = self.config.get(section, '源目录')
                                break

                    if source_dir:
                        # 将源目录替换为挂载目录
                        directory_to_scan = directory_path.replace(source_dir, self.config.get(section, '挂载目录'))
                        trigger_scan(library_id, directory_to_scan, self.config)
                        del self.pending_events[directory_path]
                        #logging.info(f"扫描：库ID: {library_id} - 路径: {directory_to_scan}")
                        #print(f"扫描：库ID: {library_id} - 路径: {directory_to_scan}")
                    else:
                        logging.error(f"无法获取源目录：库ID: {library_id}")
                except Exception as e:
                    logging.error(f"触发 Plex 扫描时出现异常：{e}")

    def stop_all_timers(self):
        for timer in self.timers.values():
            timer.cancel()


def trigger_scan(library_id, directory_to_watch, config):
    try:
        plex_url = config.get('DEFAULT', 'plex_url')
        plex_token = config.get('DEFAULT', 'plex_token')
        url = f"{plex_url}/library/sections/{library_id}/refresh"
        headers = {"X-Plex-Token": plex_token}

        # Only trigger scan for the directory itself, not its parent
        params = {"path": directory_to_watch}
        
        response = requests.get(url, headers=headers, params=params)
        response.raise_for_status()
        
        if response.status_code == 200:
            logging.info(f"扫描：库ID: {library_id} - 路径: {directory_to_watch}")
            print(f"扫描：库ID: {library_id} - 路径: {directory_to_watch}")
        else:
            logging.error(f"无法触发 Plex 扫描：库ID: {library_id} - 路径: {directory_to_watch}")
    except requests.exceptions.RequestException as e:
        logging.error(f"请求 Plex 服务器时出现异常：{e}")
    except Exception as e:
        logging.error(f"触发 Plex 扫描时出现异常：{e}")




def check_paths(config, observer, event_handler):
    monitored_paths = set()
    while True:
        for section in config.sections():
            if section.startswith("LIBRARIES"):
                directories = [config.get(section, key).strip() for key in config.options(section) if key not in ['plex_url', 'plex_token', 'scan_delay', '库ID', '源目录', '挂载目录'] and not config.get(section, key).isdigit()]
                for path in directories:
                    if os.path.exists(path):
                        if path not in monitored_paths:
                            observer.schedule(event_handler, path, recursive=True)
                            if not observer.is_alive():
                                observer.start()
                            logging.info(f"实时监控：{path}")
                            monitored_paths.add(path)
                    else:
                        logging.error(f"目录不存在，无法监控：{path}")
                        if path in monitored_paths:
                            monitored_paths.remove(path)
                            observer.unschedule_all()
                            if observer.is_alive():
                                observer.stop()
                                observer.join()
                            observer = Observer()
        time.sleep(10)  





def clear_log():
    try:
        max_log_lines = 100
        script_dir = os.path.dirname(os.path.abspath(__file__))
        log_file = os.path.join(script_dir, '日志.log')
        with open(log_file, 'r+', encoding='utf-8') as f:
            lines = f.readlines()
            if len(lines) > max_log_lines:
                f.seek(0)
                f.writelines(lines[-max_log_lines:])
                f.truncate()
    except FileNotFoundError:
        logging.error("错误：日志文件不存在")
    except Exception as e:
        logging.error(f"错误：清除日志失败: {e}")

# 定时任务管理函数
def manage_schedule_tasks():
    # 启动日志清理定时任务
    schedule.every(24).hours.do(clear_log)
    # 其他定时任务

# 在主程序中调用定时任务管理函数
manage_schedule_tasks()



if __name__ == "__main__":
    script_dir = os.path.dirname(os.path.abspath(__file__))
    log_file = os.path.join(script_dir, '日志.log')
    logging.basicConfig(filename=log_file, level=logging.INFO,
                        format='%(levelname)s - %(asctime)s - %(message)s',
                        datefmt='%m-%d %H:%M')

    try:
        config_file = os.path.join(script_dir, 'config.ini')
        config = configparser.ConfigParser()
        config.read(config_file, encoding='utf-8')
    except FileNotFoundError as e:
        logging.error("错误：配置文件不存在: %s", e)
    except configparser.Error as e:
        logging.error("错误：配置文件格式不正确: %s", e)

    observer = Observer()
    event_handler = CustomEventHandler(config)

    try:
        for section in config.sections():
            if section.startswith("LIBRARIES"):
                directories = [config.get(section, key).strip() for key in config.options(section) if key not in ['plex_url', 'plex_token', 'scan_delay', '库ID', '源目录', '挂载目录'] and not config.get(section, key).isdigit()]
                for path in directories:
                    if os.path.exists(path):
                        observer.schedule(event_handler, path, recursive=True)
                        #logging.info(f"实时监控：{path}")
            else:
                logging.warning(f"配置文件中存在未知节：{section}")

        observer.start()

        # 在主函数中启动这个检查路径的线程
        threading.Thread(target=check_paths, args=(config, observer, event_handler)).start()

        while True:
            schedule.run_pending()
            time.sleep(1)

    except KeyboardInterrupt:
        observer.stop()
        event_handler.stop_all_timers()
        observer.join()
    except Exception as e:
        logging.error(f"启动监控时出现异常：{e}")
        traceback.print_exc()
    finally:
        observer.stop()
        event_handler.stop_all_timers()
        observer.join()
        logging.error("脚本已停止运行")